<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>HW2 Sign Up Page</title>
</head>
<body>
<div>
      
      
      
      <div>
        <div>   
          <h1>Sign Up for Free</h1>
          
          <form action="signup.php" method="POST">
          
          <div>
            <div>
              <label>
                Username<span>:</span>
              </label>
              <input type="text" name ="username" required autocomplete="off" />
            </div>
            </div>

         
          
          <div>
            <label>
              Set A Password<span>:</span>
            </label>
            <input type="password" name ="pass" required autocomplete="off"/>
          </div>
          
          <input type = "submit" name="submit" value="submit">
          Already Registered? 
         <a href="http://cs3380.rnet.missouri.edu/~klft2/hw2/login.php">Click Here!</a>
          </form>

        </div>
        
    </div><!-- tab-content -->
      
</div> <!-- /form -->


</body>
</html>

<?php
	$hostname = 'localhost';
    $username = 'klft2';
    $password = 'likexin#0304';
    $database = 'klft2';
    $link = mysqli_connect($hostname, $username, $password, $database) or die ("connection Error on Line 52: ".mysqli_connect_error());

	
	// username varchar(50),
    // password varchar(18)

    if(isset($_POST['submit']))
    {
       //  echo "test";
        $username = $_POST['username'];
        $password = $_POST['pass'];
 		
 		// echo "test2";
 		
        if($stmt = mysqli_prepare($link,"INSERT INTO USERS VALUES (?,?)"))
        {
        	// echo "test3";
            mysqli_stmt_bind_param($stmt,"ss",$username,$password);
            if(mysqli_stmt_execute($stmt))
            {
                header("Location:http://cs3380.rnet.missouri.edu/~klft2/hw2/succes.html");
            }
            else
            {
                echo "Please try again or change your username!";
            }
            mysqli_stmt_close($stmt);
        }
    }
	
	
?>
		





