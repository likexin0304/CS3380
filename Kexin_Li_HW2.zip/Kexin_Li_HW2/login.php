<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login Page</title>
</head>
<body>
<form action="" method="POST">
 <div>
    <label><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username">

    <label><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password">

    <input type = "submit"  name = "submit" value = "submit"/><br />
     Not Already Registered? 
    <a href="http://cs3380.rnet.missouri.edu/~klft2/hw2/signup.php">Go to Sign Up !</a>
  </div>
</form>

<?php
            
            $hostname = 'localhost';
            $username = 'klft2';
            $password = 'likexin#0304';
            $database = 'klft2';
           	$link = mysqli_connect($hostname, $username, $password, $database) or die ("connection Error on Line 24: ".mysqli_connect_error());
        	
        	
        	$username = $_POST['username'];
	        $password = $_POST['password'];
	        
            $sql = mysqli_query($link,"SELECT * FROM USERS WHERE username = '$username' AND password = '$password';");
	
	        session_start();
	        $_SESSION['username'] = $_POST['username'];
	        if(isset($_POST['submit']))
            {
		       if(mysqli_num_rows($sql)==0)
               {
			          echo"Invalid Username or Password. Please enter username and password again.";
		       }
               else
               {
			         header("Location:http://cs3380.rnet.missouri.edu/~klft2/hw2/welcome.php");
               }
	        }
        	
?>


</body>
</html>