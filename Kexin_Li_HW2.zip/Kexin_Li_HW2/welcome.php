<?php
   include('session.php');
?>
<!DOCTYPE HTML>
<html lang="en">
   
   <head>
      <title>Welcome Page </title>
   </head>
   
   <body>
      <form action = "login.php">
      <?php
      	session_start();
      	echo"Welcome ".$_SESSION['username'].", Successfully Logged in !";
      ?>      
       </form>
    </body>
   
</html>