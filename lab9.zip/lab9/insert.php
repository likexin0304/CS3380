<html>
    <head>
        <meta charset="utf-8">
        <title>Lab8 Insert</title>
       <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

        <!-- Latest compiled and minified JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        
        <style>
        
        #wrapper
        {
            text-align: center;    
        }
        
        #home
        {
            color: red;
        }
        </style>
    </head>
    <body>
        <br>
        <a id="home" href = "http://cs3380.rnet.missouri.edu/~klft2/lab8/lab8.php">Home</a>
        <br>
        
        <div id="wrapper">
        <form method = "post" action="./lab8.php">
            Class Name:
            <input type="text" name="name">
            Department:
            <input type="text" name="department">
            Course ID:
            <input type="text" name="course_id">
            <br>
            <br>
            <br>
            <br>
            Start Time:
            
            <select name="starthour">
                <?php
                    $j =0 ;
                    for($i=0;$i<10;$i++){              
                        echo "<option value = '".$i."'>".$j.$i."</option>";
                    }
                    for($i=10;$i<24;$i++){              
                        echo "<option value = '".$i."'>".$i."</option>";
                    }
                ?>
            </select>
            
            <select name="startminute">
                <?php
                    $j =0 ;
                    for($i=0;$i<10;$i++){              
                        echo "<option value = '".$i."'>".$j.$i."</option>";
                    }
                    for($i=10;$i<60;$i++){              
                        echo "<option value = '".$i."'>".$i."</option>";
                    }
                ?>
            </select>
            
            End Time:
            
            <select name="endhour">
                <?php
                    $j =0 ;
                    for($i=0;$i<10;$i++){              
                        echo "<option value = '".$i."'>".$j.$i."</option>";
                    }
                    for($i=10;$i<24;$i++){              
                        echo "<option value = '".$i."'>".$i."</option>";
                    }
                ?>
            
            </select>
            
            <select name="endminute">
                <?php
                    $j =0 ;
                    for($i=0;$i<10;$i++){              
                        echo "<option value = '".$i."'>".$j.$i."</option>";
                    }
                    for($i=10;$i<60;$i++){              
                        echo "<option value = '".$i."'>".$i."</option>";
                    }
                ?>
            </select>
            
            Day:
            
            <select name="days">
                <option value = "1">MWF</option>
                <option value = "2">TTH</option>
            </select>
            
            <input type = "submit" name="submit" value="submit">
        
        </form>
        </div>
    </body>

</html>