<!DOCTYPE html>
<html lang="en">
	<head>
    <meta charset="UTF-8">
    <title>Home Page lab 9 and lab 10</title>
	<link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel = "stylesheet" href = "https:://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
	<script src = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	</head>	

<body>
<a href = "http://cs3380.rnet.missouri.edu/~klft2/lab9/insert.php">Insert Into classes</a>
<hr>
<form action = "" method = "POST" class = "col-md-4 col-md-offset-5">

Search:
	<input type = "text" name = "search">
<br><br>
<!--<select name = "radio">-->
	<input type="radio" name="radios" value="0" checked="check">Name
	<input type="radio" name="radios" value="1">Department
	<input type="radio" name="radios" value="2">Course ID		
	<br><br>
	<input class = "btn btn-primary" type = "submit" name = "submit" value = "Search">
</form>

<hr>
        
        <?php
            
            $hostname = 'localhost';
            $username = 'klft2';
            $password = 'likexin#0304';
            $database = 'klft2';
            $link = mysqli_connect($hostname, $username, $password, $database) or die ("connection Error on Line 42: ".mysqli_connect_error());
        	
        
        
            if(isset($_POST['submit'])){
		     
            
              
			         switch($_POST['radios'])
                     {
				        case 0:
					    $query = "SELECT * FROM classes WHERE name LIKE ?";		
					    break;
				        case 1:
					    $query = "SELECT * FROM classes WHERE department LIKE ?";
					    break;
				        case 2:
					    $query = "SELECT * FROM classes WHERE course_id LIKE ?";
					    break;
                     }
                     
            	if($stmt = mysqli_prepare($link,$query)){
                    echo "perpare success";}else{
                    echo "prepare error on Line 59: ";}
				$find = $_POST['search'].'%';
				
				if(mysqli_stmt_bind_param($stmt,"s",$find)){
                    echo "bind success";}else{
                    echo "bind error on Line 59: ";}	
				
				if(mysqli_stmt_execute($stmt))
				{
					
					if(mysqli_stmt_bind_result($stmt,$name,$department,$courseid,$start,$end,$days) ){
                    echo "bind result  success";}else{
                    echo "bind  result failed on Line 59: ";}
                    
					echo"<table class = 'table table-hover'><thead>";
                    
//                    echo "test1";
					echo"<tr><th>Name</th><th>Department</th><th>Course_ID</th><th>Start</th><th>End</th><th>Days</th></tr>";
//                    echo "test2";
                    
                 
					while(mysqli_stmt_fetch($stmt)){
//                        echo"test3";
						echo"<tr><td>$name</td><td>$department</td><td>$courseid</td><td>$start<td><td>$end</td><td>$days</td>";
                        
                        echo"<td><form method='POST' action='update.php'>";
                        echo"<input type=hidden name='name' value='$name'>";
                        echo"<input type=hidden name='department' value='$department'>";
                        echo"<input type=hidden name='courseid' value='$courseid'>";
                        echo"<input type=hidden name='start' value='$start'>";
                        echo"<input type=hidden name='end' value='$end'>";
                        echo"<input type=hidden name='days' value='$days'>";
                        echo"<input type=submit name='update' value='update' class='btn'>";
                        echo"</form></td>";
                        
                        echo"<td><form method='POST' action='lab9.php'>";
                        echo"<input type=hidden name='name' value='$name'>";
                        echo"<input type=hidden name='department' value='$department'>";
                        echo"<input type=hidden name='courseiddd' value='$courseid'>";
                        echo"<input type=hidden name='start' value='$start'>";
                        echo"<input type=hidden name='end' value='$end'>";
                        echo"<input type=hidden name='days' value='$days'>";
                        echo"<input type=submit name='delete' value='delete' class='btn'>";
                        echo"</form></td>";
                        
                        
                        echo"</tr>";
            		}
                    echo"</table>";
            	}
                else
            	{
            		echo "execute error!";
            	}
                
              
            }
                
        ?>
    
    
    
    </body>
</html>
<?php
    
    if(isset($_POST['delete'])){
        $hostname = 'localhost';
        $username = 'klft2';
        $password = 'likexin#0304';
        $database = 'klft2';
        $link = mysqli_connect($hostname, $username, $password, $database) or die ("connection Error on Line 42: ".mysqli_connect_error());


        $sql = "DELETE FROM classes WHERE course_id= ?";
            
            if($stmt = mysqli_prepare($link,$sql)) {
                    echo "perpare success";
            }
            else {
                    echo "prepare error on Line 134: ";
            }

            if(mysqli_stmt_bind_param($stmt,"s", $_POST['courseiddd'])) {
                    echo "bind success";
            }
            else {
                    echo "bind error on Line 141: ";
            }
            if(mysqli_stmt_execute($stmt))
            {
                 header("Location:lab9.php");
            }
            else
            {
                echo"Cannot delete!!";
            }
        }


