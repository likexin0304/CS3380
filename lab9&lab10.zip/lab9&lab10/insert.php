<!DOCTYPE html>
<html lang="en">
   <head>
        <link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
        <link rel = "stylesheet" href = "https:://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
        <script src = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js">
        </script>
   </head>
<body>
<a href = "http://cs3380.rnet.missouri.edu/~klft2/lab9/lab9.php">Home</a>
<hr>
<form action = "" method = "POST" class = "col-md-4 col-md-offset-5">
    

    <input type = "text" name = "name">Class Title<br><br>
	<input type = "text" name = "department">Department<br><br>
	<input type = "text" name = "course_id">Course_ID<br><br>
	Start Time:<tr></tr>
	<select name = "start_hour">
	<?php
	
		for($i=0;$i<10;$i++)
		{
			?>
			<option value = "<?php echo $i;?>">0<?php echo $i;?></option>
		<?php
		}
		for($i=10;$i<24;$i++)
                {
                        ?>
                        <option value = "<?php echo $i;?>"><?php echo $i;?></option>
                <?php
                }
	?>
	</select>
	<select name = "start_min">
	<?php
		for($i=0;$i<10;$i++)
                {
                        ?>
                        <option value = "<?php echo $i;?>">0<?php echo $i;?></option>
                        <?php
                }
		for($i=10;$i<60;$i++)
                {
                        ?>
                        <option value = "<?php echo $i;?>"><?php echo $i;?></option>
                <?php
                }
        ?>
        </select><tr></tr>
	
	<br><br>End Time:
        <select name = "end_hour">
        <?php
                for($i=0;$i<10;$i++)
                {
                        ?>
                        <option value = "<?php echo $i;?>">0<?php echo $i;?></option>
                <?php
        	}
		for($i=10;$i<24;$i++)
		{
			?>
			<option value = "<?php echo $i;?>"><?php echo $i;?></option>
		<?php
		}
	?>
        </select>
        <select name = "end_min">
        <?php
                for($i=0;$i<10;$i++)
                {
                        ?>
                        <option value = "<?php echo $i;?>">0<?php echo $i;?></option>
                <?php
                }
		for($i=10;$i<60;$i++)
                {
                        ?>
                        <option value = "<?php echo $i;?>"><?php echo $i;?></option>
                <?php
                }
        ?>
    </select><tr></tr>
	<br><br>Days:
	<select name = "days">
	  <option value = "MWF">MWF</option>
	  <option value = "TTH">TTH</option>
	  
	</select>
	<br><br>
	<input class = "btn btn-primary" type = "submit" name = "submit" value = "Insert" ><br><br>
</form>
<hr>
<?php
	if(isset($_POST['submit'])){
        
    $hostname = 'localhost';
    $username = 'klft2';
    $password = 'likexin#0304';
    $database = 'klft2';
    $link = mysqli_connect($hostname, $username, $password, $database) or die ("connection Error on Line 42: ".mysqli_connect_error());
    
	$sql = "INSERT INTO classes VALUES (?,?,?,?,?,?)";
	if($stmt = mysqli_prepare($link,$sql)){
		$start = $_POST['start_hour'].':'.$_POST['start_min'];
		$end = $_POST['end_hour'].':'.$_POST['end_min'];
		mysqli_stmt_bind_param($stmt, "ssssss",$_POST['name'],$_POST['department'],$_POST['course_id'],$start,$end,$_POST['days'])or die("Line 28".mysqli_connect_error());
		if(mysqli_stmt_execute($stmt)){
			echo"class Added";
			}else{
			echo"class add error on line 32";
		}
	}else{
		die("Line 30");
	}
	
}

?>

</body>
</html>
