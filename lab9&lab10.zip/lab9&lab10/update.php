<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Page</title>
    <link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel = "stylesheet" href = "https:://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css">
	<script src = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
</head>
<body>
    <a href = "http://cs3380.rnet.missouri.edu/~klft2/lab9/lab9.php">Home Page</a>
    <br>
    <br>

    <form action = "" method = "POST" class = "col-md-4 col-md-offset-5">
    <?php
        echo"Name : <input type='text' name='namee' value='".$_POST['name']."'>";
        echo"<br><br>";
        echo"Dapartment : <input type='text' name='departmentt' value='".$_POST['department']."'>";
        echo"<br><br>";
        echo"Course_ID : <input type='text' name='courseidd' value='".$_POST['courseid']."' readonly>";
        echo"<br><br>";
        echo"Start : <input type='text' name='startt' value='".$_POST['start']."'>";
        echo"<br><br>";
        echo"End: <input type='text' name='endd' value='".$_POST['end']."'>";
        echo"<br><br>";
        echo"Days : 
        <select name = 'dayss' value='".$_POST['days']."'>
	    <option value = 'MWF'>MWF</option>
	    <option value = 'TTH'>TTH</option>
	    </select>";
        echo"<br><br>";
        
        
        
    ?>

	<input class = "btn btn-primary" type = "submit" name = "updatee" value = "update">
    </form>



</body>
</html>


<?php
    
    if(isset($_POST['updatee'])){
            $hostname = 'localhost';
            $username = 'klft2';
            $password = 'likexin#0304';
            $database = 'klft2';
            $link = mysqli_connect($hostname, $username, $password, $database) or die ("connection Error on Line 42: ".mysqli_connect_error());

            $sql = "UPDATE classes SET name = ?, department = ?, start = ?, end = ?, days = ? WHERE course_id= ?";
            
            if($stmt = mysqli_prepare($link,$sql)) {
                    echo "perpare success";
            }
            else {
                    echo "prepare error on Line 57: ";
            }

            if(mysqli_stmt_bind_param($stmt,"ssssss",$_POST['namee'], $_POST['departmentt'], $_POST['startt'], $_POST['endd'], $_POST['dayss'], $_POST['courseidd'])) {
                    echo "bind success";
            }
            else {
                    echo "bind error on Line 64: ";
            }
            if(mysqli_stmt_execute($stmt))
            {
                 header("Location:lab9.php");
            }
            else
            {
                echo"Did not update !!";
            }
      
    }
?>








    